let slider = tns({
    container: '.slider-container',
    items:4,
    autoplay:true,
    muosedrag:true,
    controls:false,
    nav:false,
    autoplayButtonOutput: false,
    autoplayTimeout:5000,
    gutter: 30,
   })