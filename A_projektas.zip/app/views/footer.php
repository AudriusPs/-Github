 <footer class="">
   <div class="container-footer-wide">
     <div class="container container-fluid container-footer text-white pt-5">
       <div class="row container-footer-row">
         <div class="col-md-6 col-lg-4 col-xl-4 coll-soc">
           <img alt="" src="../app/images/13.png" class="img-fluid p-2">
           <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever industry. Lorem Ipsum has been the lorem.</p>
           <div class="pt-2">
             <a href="" class="text-decoration-none text-white me-4">
               <i class="bi bi-facebook"></i>
             </a>
             <a href="" class="text-decoration-none text-white me-4">
               <i class="bi bi-twitter"></i>
             </a>
             <a href="" class="text-decoration-none text-white me-4">
               <i class="bi bi-pinterest"></i>
             </a>
             <a href="" class="text-decoration-none text-white me-4">
               <i class="bi bi-instagram"></i>
             </a>
             <a href="" class="text-decoration-none text-white me-4">
               <i class="bi bi-youtube"></i>
             </a>
           </div>
         </div>
         <div class="col-md-6 col-lg-2 col-xl-2">
           <h6 class="fw-bold">Resent Post</h6>
           <p>
             <a href="#!" class="text-white text-decoration-none">About</a>
           </p>
           <p>
             <a href="#!" class="text-white text-decoration-none">FAQ</a>
           </p>
           <p>
             <a href="#!" class="text-white text-decoration-none">Career</a>
           </p>
           <p>
             <a href="#!" class="text-white text-decoration-none">Our Team</a>
           </p>
           <p>
             <a href="#!" class="text-white text-decoration-none">Services</a>
           </p>
         </div>
         <div class="col-md-6 col-lg-3 col-xl-3">
           <h6>Working Hours</h6>
           <p>Monday -- Friday: 8am -- 6pm EST</p>
           <p>Saturday: 9am -- 5pm EST</p>
           <p>Sunday: 9am -- 4pm EST</p>
         </div>
         <div class="col-md-6 col-lg-3 col-xl-3">
           <h6>Contact Us</h6>
           <p>
             <a href="#!" class="text-white text-decoration-none">90 St Johns Brooklyn, NY, United States</a>
           </p>
           <p>
             <a href="mailto:contact.louisvillebeautysalon@gmail.com" class="text-white text-decoration-none">contact.louisvillebeautysalon@gmail.com</a>
           </p>
           <p>
             <a href="tel:0188899977" class="text-white text-decoration-none">Phone: (+01)888.999.77</a>
           </p>
         </div>
       </div>
     </div>
   </div>
   <div class="bottom-wide botom-bar">
     <div class="container">
       <div class="row align-items-center botom-bar">
         <div class="col-12 col-md-6 col-lg-8 text-start pt-2">
           <p class="text-white text-decoration-none">&copy; Copyright Louisville Beauty Salon All rights reserved.</p>
         </div>
         <div class="col-12 col-md-6 col-lg-4">
           <div class="row align-items-center botom-bar pt-2">
             <div class="col-12 col-md-6 col-lg-8 text-end">
               <p>
                 <a href="#!" class="text-white text-decoration-none">Privacy Policy</a>
               </p>
             </div>
             <div class="col-12 col-md-6 col-lg-4">
               <p>
                 <a href="#!" class="text-white text-decoration-none">Terms of Use</a>
               </p>
             </div>
           </div>
         </div>
       </div>
     </div>
   </div>
 </footer>