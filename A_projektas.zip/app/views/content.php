<main>
  <!-- Hero -->
  <div class="container-hero d-flex justify-content-center align-items-center">
    <div class="text-white">
      <h1>Laser Skin Resurfacing</h1>
    </div>
  </div>
  <!-- Hero END -->
  <!-- about -->
  <div class="container container-about">
    <div class="row">
      <div class="col-md-12 col-xl-6 overlay">
        <img class=".img-fluid remelis" src="../app/images/Rectangle4.png" alt="Rectangle">
        <img class=".img-fluid image1 img-responsive" src="../app/images/senior-female.jpg" alt="senior-female-getting">
      </div>
      <div class="col-md-12 col-xl-6 text-left pt-5 pe-4">
        <h4>We provide</h4>
        <h2>Welcome to Spa Center</h2>
        <p>Spread over two floors, our beautiful spa offer a soothing environment in which you can rest, relax and feel competely rejuvenated.</p>
        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. remaining essentially unchanged. It was popularised in the with theLorem Ipsum is simply dummy text of the printing and eentially unchanged.</p>
      </div>
    </div>
  </div>
  <!--end about -->
  <!-- Our Services -->
  <div class="container-services-wide">
    <div class="container container-services">
      <div class="row services-h2">
        <div class="col-12 text-center">
          <h2>Our Services</h2>
        </div>
      </div>
      <div class="row services-p">
        <div class="col-12 text-center">
          <p>Spread over two floors, our beautiful spa offer a soothing environment in which you can rest, relax and feel competely rejuvenated.</p>
          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. remaining essentially unchanged. It was popularised in the with theLorem Ipsum is simply dummy text of the printing and eentially unchanged.</p>
        </div>
        <div>
          <div class="row justify-content-between">
            <div class="col-sm-2 circle-container">
              <div id="circle-1" class="circle circle-group"></div>
              <h4>Spa</h4>
            </div>
            <div class="col-sm-2 circle-container circle-group">
              <div id="circle-2" class="circle"></div>
              <h4>Hair Makeup</h4>
            </div>
            <div class="col-sm-2 circle-container circle-group">
              <div id="circle-3" class="circle"></div>
              <h4>Waxing</h4>
            </div>
            <div class="col-sm-2 circle-container circle-group">
              <div id="circle-4" class="circle"></div>
              <h4>Facial</h4>
            </div>
            <div class="col-sm-2 circle-container circle-group">
              <div id="circle-5" class="circle"></div>
              <h4>Massage</h4>
            </div>
          </div>
        </div>
        <div class="services-table bg-white">
          <div class="row services-box">
            <div class="col-12 col-md-6 col-lg-3 text-left pt-4 ps-0">
              <ul class="list-group services-menu-ul list-unstyled">
                <li class="list-group-item list-item">
                  <a class="services-menu text-black text-decoration-none" href="#">
                    <img src="../app/images/massage6.png" alt="Massage Therapy Icon" class="icon i-massage6">Massage Therapy </a>
                </li>
                <li class="list-group-item list-item">
                  <a class="services-menu text-black text-decoration-none" href="#">
                    <img src="../app/images/massage6.png" alt="Massage Therapy Icon" class="icon  i-massage6">Facials </a>
                </li>
                <li class="list-group-item list-item">
                  <a class="services-menu text-black text-decoration-none" href="#">
                    <img src="../app/images/massage6.png" alt="Massage Therapy Icon" class="icon  i-massage6">Pedicures </a>
                </li>
                <li class="list-group-item list-item">
                  <a class="services-menu text-black text-decoration-none" href="#">
                    <img src="../app/images/massage6.png" alt="Massage Therapy Icon" class="icon  i-massage6">Manicures </a>
                </li>
                <li class="list-group-item list-item">
                  <a class="services-menu text-black text-decoration-none" href="#">
                    <img src="../app/images/massage6.png" alt="Massage Therapy Icon" class="icon  i-massage6">Body Wraps </a>
                </li>
                <li class="list-group-item list-item">
                  <a class="services-menu text-black text-decoration-none" href="#">
                    <img src="../app/images/massage6.png" alt="Massage Therapy Icon" class="icon  i-massage6">Waxing & Cosmetics </a>
                </li>
              </ul>
            </div>
            <div class="col-12 col-md-6 col-lg-4 pt-4">
              <div id="circle-services" class="circle border border-5"></div>
            </div>
            <div class="col-12 col-md-12 col-lg-5 text-left pt-5 services-text">
              <h2>Massage Therapy</h2>
              <h4>$40 - $80</h4>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. remaining essentially unchanged. It was popularised in the with theLorem Ipsum is simply dummy text of the printing and eentially unchanged.</p>
              <h6>
                <a href="" class="text-decoration-none">Read More</a>
              </h6>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Our Services END-->
  <!-- BEAUTY AND SPA CENTER -->
  <div class="container container-spa">
    <div class="row">
      <div class="col-auto heading-spa">
        <h2>BEAUTY AND SPA CENTER</h2>
        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. remaining essentially unchanged. It was popularised in the with theLorem Ipsum is simply dummy text of the printing and eentially unchanged.</p>
      </div>
    </div>
    <div class="spa-galery">
      <div class="row">
        <div class="col-12 col-md-6 col-lg-4">
          <div class="card rounded-0 card-css">
            <img class="card-img-top img-fluid" src="../app/images/woman-treatment-procedures.jpg" alt="woman-treatment-procedures">
            <div class="card-img-overlay cadr-i-o">
              <div class="overlay-box bg-white opacity-75 text-center over-box">
                <p>Sauna Massage</p>
                <h6 class="card-title">NATURAL HEALTH</h6>
                <br>
                <br>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-md-6 col-lg-4">
          <div class="card rounded-0 card-css">
            <img class="card-img-top" src="../app/images/1.jpg" alt="face procedures">
            <div class="card-img-overlay cadr-i-o">
              <div class="overlay-box bg-white opacity-75 text-center over-box">
                <p>Spa Treatment</p>
                <h6 class="card-title">Mind Relaxation</h6>
                <br>
                <br>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-md-6 col-lg-4">
          <div class="card rounded-0 card-css">
            <img class="card-img-top" src="../app/images/woman-cosmetology.jpg" alt="hand procedures">
            <div class="card-img-overlay cadr-i-o">
              <div class="overlay-box bg-white opacity-75 text-center over-box">
                <p>Cosmetology</p>
                <h6 class="card-title">Essential Balance</h6>
                <br>
                <br>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- BEAUTY AND SPA CENTER end-->
  <!-- team -->
  <div class=" container-team-wide">
   <div class="container container-team p-4">
     <div class="row team-h2">
       <div class="col-12 col-md-12 col-lg-2 text-center"></div>
       <div class="col-12 col-md-12 col-lg-8 text-center">
         <h2>Our Experience Specialists</h2>
       </div>
       <div class="col-12 col-md-12 col-lg-2 text-center"></div>
     </div>
     <div class="row team-p">
       <div class="col-12 col-md-12 col-lg-2 text-center"></div>
       <div class="col-12 col-md-12 col-lg-8 text-center">
         <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
       </div>
       <div class="col-12 col-md-12 col-lg-2 text-center"></div>
     </div>
     <div class="Specialists-galery">
       <div class="row">
         <div class="col-12 col-md-6 col-lg-4">
           <div class="image-container container-team-1">
             <a href="">
               <img src="../app/images/expert1.jpg" class="img-fluid image-team-1" alt="expert1">
             </a>
             <div class="middle-team-1">
               <div class="text-team-1">
                 <h4>Mattie Joshef</h4>
                 <p>Dermatologist</p>
               </div>
             </div>
           </div>
         </div>
         <div class="col-12 col-md-6 col-lg-4">
           <div class="image-container container-team-2">
             <a href="">
               <img src="../app/images/expert2.jpg" class="img-fluid image-team-2" alt="expert2">
             </a>
             <div class="middle-team-2">
               <div class="text-team-2">
                 <h4>Mattie Joshef</h4>
                 <p>Dermatologist</p>
               </div>
             </div>
           </div>
         </div>
         <div class="col-12 col-md-6 col-lg-4">
           <div class="image-container container-team-3">
             <a href="">
               <img src="../app/images/expert3.jpg" class="img-fluid image-team-3" alt="expert3">
             </a>
             <div class="middle-team-3">
               <div class="text-team-3">
                 <h4>Mattie Joshef</h4>
                 <p>Dermatologist</p>
               </div>
             </div>
           </div>
         </div>
       </div>
     </div>
   </div>
 </div>
  <!-- team end-->
  <!-- products -->
  <div class="container container-products bg-white">
    <div class="row">
      <div class="col-12 col-md-12 col-xl-7">
        <div class="row">
          <div class="col-12 products-text">
            <h2>Our Exclusive Products</h2>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
          </div>
        </div>
      </div>
      <div class="col-12 col-md-12 col-xl-5">
        <div class="row">
          <div class="col-md-12 col-xl-8"></div>
          <div class="col-md-12 col-xl-3">
            <button class="btn btn-primary" id="submit2" name="submit2" type="submit">All Products</button>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="slider">
          <div class="container">
            <div class="slider-container">
              <div>
                <img src="../app/images/product1.png" alt="product1">
              </div>
              <div>
                <img src="../app/images/product2.png" alt="product2">
              </div>
              <div>
                <img src="../app/images/product3.png" alt="product3">
              </div>
              <div>
                <img src="../app/images/product4.png" alt="product4">
              </div>
              <div>
                <img src="../app/images/product1.png" alt="product1">
              </div>
              <div>
                <img src="../app/images/product2.png" alt="product2">
              </div>
              <div>
                <img src="../app/images/product3.png" alt="product3">
              </div>
              <div>
                <img src="../app/images/product4.png" alt="product4">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- products end-->
  <!-- offers -->
  <div class="container-offers-wide">
    <div class="container container-offers">
      <div class="row offers">
        <div class="col-12 col-md-12 col-xl-7 text-left">
          <div class="row">
            <div class="col-12 col-md-12 col-xl-12 text-left">
              <h2>Our Special Offers</h2>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
              <div>
                <img src="../app/images/image1.jpg" alt="counter">
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-md-12 col-xl-5 overlay">
          <img class=".img-fluid ausys" src="../app/images/Ellipse7.png" alt="ausys">
          <img class=".img-fluid img-responsive image-off" src="../app/images/two-women-beautician.jpg" alt="two-women-beautician">
        </div>
      </div>
    </div>
  </div>
  <!--end offers -->
  <!--contacts -->
  <div class="container-contact-wide">
   <div class="row">
     <div class="col-12 col-md-12 col-lg-3 text-center"></div>
     <div class="col-12 col-md-12 col-lg-6 text-center">
       <div class="container container-contact-big">
         <div class="row contact-h2">
           <div class="col-12 col-md-12 col-lg-2 text-center"></div>
           <div class="col-12 col-md-12 col-lg-8 text-center text-white">
             <h2>Make An Appointment</h2>
           </div>
           <div class="col-12 col-md-12 col-lg-2 text-center"></div>
         </div>
         <div class="row contact-p">
           <div class="col-12 col-md-12 col-lg-1 text-center"></div>
           <div class="col-12 col-md-12 col-lg-10 text-center text-white">
             <p>Lorem Ipsum is simply dummy text of the printing and typesetting <br>Lorem Ipsum has been industry </p>
           </div>
           <div class="col-12 col-md-12 col-lg-1 text-center"></div>
           <div class="container container-contact bg-white p-4">
             <div class="row">
               <form id="contact" action="index.php" method="post">
                 <div class="row contact-y-1">
                   <div class="col-md-12 col-xl-6">
                     <div class="">
                       <input class="form-control" id="name" name="vardas" type="text" placeholder="Name" required>
                     </div>
                   </div>
                   <div class="col-md-12 col-xl-6">
                     <div class="">
                       <input class="form-control" id="emailAddress" name="email" type="email" placeholder="Email" required>
                     </div>
                   </div>
                 </div>
                 <div class="row contact-y-2">
                   <div class="col-md-12 col-xl-6">
                     <div class="">
                       <input class="form-control" id="phone" type="text" placeholder="Phone">
                     </div>
                   </div>
                   <div class="col-md-12 col-xl-6">
                     <div class="">
                       <textarea class="form-control" id="message" name="message" placeholder="Message" rows="1"></textarea>
                     </div>
                   </div>
                 </div>
                 <div class="row contact-y-3">
                   <div class="col-8"></div>
                   <div class="col-4">
                     <button class="btn btn-primary" id="submit" name="submit" type="submit">Send</button>
                   </div>
                 </div>
               </form>
             </div>
           </div>
         </div>
       </div>
     </div>
     <div class="col-12 col-md-12 col-lg-3 text-center"></div>
   </div>
 </div>
  <!--end contact -->
  <!-- blog -->
  <div class="container container-blog">
    <div class="row">
      <div class="col-12 text-center">
        <h2>Our Blog</h2>
      </div>
    </div>
    <div class="row blog-p">
      <div class="col-12 text-center">
        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
      </div>
    </div>
    <div class="row blog-galery">
      <div class="col-12 col-md-12 col-lg-6 col-blog pt-5 ps-1 pe-4">
        <div class="card-blog-1">
          <img src="../app/images/2.jpg" class="card-img-top" alt="laser procedure">
          <div class="card-body-blog">
            <div class="row blog-row">
              <div class="row blog-row-comm bg-white align-items-center">
                <div class="col-1">
                  <img src="../app/images/3.jpg" alt="blog comenter" class="rounded-circle blog-elipse">
                </div>
                <div class="col-7">
                  <p>Rubina Alfa</p>
                </div>
                <div class="col-4">
                  <p>
                    <img src="../app/images/calendar.png" alt="calendar Icon" class="icon">12 Oct 2021
                  </p>
                </div>
              </div>
            </div>
            <div class="row text-left pt-3 ps-5">
              <h4>Specialty Spa Treatments For Your Face, Body, Hands, & Feet</h4>
            </div>
            <div class="row ps-5 pt-4">
              <a href="#" class="btn btn-primary read-more">Read More</a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-12 col-md-12 col-lg-6 col-blog pt-5 pe-1">
        <div class="card-body-blog card-body-blog-1">
          <div class="row blog-row">
            <div class="row blog-row-comm bg-white align-items-center">
              <div class="col-1">
                <img src="../app/images/3.jpg" alt="blog comenter" class="rounded-circle blog-elipse">
              </div>
              <div class="col-7">
                <p>Rubina Alfa</p>
              </div>
              <div class="col-4">
                <p>
                  <img src="../app/images/calendar.png" alt="calendar Icon" class="icon">12 Oct 2021
                </p>
              </div>
            </div>
          </div>
          <div class="row text-left pt-3 ps-5 pe-5">
            <h4>Specialty Spa Treatments For Your Face, Body, Hands, & Feet</h4>
          </div>
          <div class="row ps-5 pt-4">
            <a href="#" class="btn btn-primary read-more">Read More</a>
          </div>
        </div>
        <div class="card-body-blog card-body-blog-2">
          <div class="row blog-row">
            <div class="row blog-row-comm bg-white align-items-center">
              <div class="col-1">
                <img src="../app/images/3.jpg" alt="blog comenter" class="rounded-circle blog-elipse">
              </div>
              <div class="col-7">
                <p>Rubina Alfa</p>
              </div>
              <div class="col-4">
                <p>
                  <img src="../app/images/calendar.png" alt="calendar Icon" class="icon">12 Oct 2021
                </p>
              </div>
            </div>
          </div>
          <div class="row text-left pt-3 ps-5 pe-5">
            <h4>Specialty Spa Treatments For Your Face, Body, Hands, & Feet</h4>
          </div>
          <div class="row ps-5 pt-4">
            <a href="#" class="btn btn-primary read-more">Read More</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- blog end-->
</main>