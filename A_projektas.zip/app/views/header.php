 <header>
   <div class="container-top-bar">
     <div class="container">
       <div class="row">
         <div class="d-flex align-items-center flex-row">
           <a href="mailto:info@louisvillebeautysalon.com" class="text-decoration-none text-black ps-4 mail">
             <i class="bi bi-envelope me-1"></i>
             <span class="contacts-text">info@louisvillebeautysalon.com</span>
           </a>
           <div class="vr ms-4" id="vertical-line"></div>
           <div class="d-flex align-items-center">
             <a href="tel:+654555555" class="text-decoration-none text-black ps-4">
               <i class="bi bi-telephone me-1"></i>
               <span class="contacts-text">+654 555555</span>
             </a>
           </div>
         </div>
       </div>
     </div>
   </div>
   <nav id="navbar_top" class="navbar navbar-expand-lg bg-white sticky-top">
     <div class="container container-fluid">
       <a class="navbar-brand float-left ps-4" href="/">
         <img src="../app/images/LOGO.png" alt="logo">
       </a>
       <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
         <span class="navbar-toggler-icon"></span>
       </button>
       <div class="collapse navbar-collapse" id="navbarNavDropdown">
         <ul class="navbar-nav nav flex-row float-right">
           <li class="nav-item">
             <a class="nav-link" href="#">Liposuction</a>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="#">Coolsculpting</a>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="#">Ultherapy</a>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="#">Laser Treatments</a>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="#">Med Spa</a>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="#">Spa Menu</a>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="#">Shop</a>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="#">Events</a>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="#">Specials</a>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="#">About</a>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="#">Contact</a>
           </li>
         </ul>
       </div>
     </div>
   </nav>
 </header>