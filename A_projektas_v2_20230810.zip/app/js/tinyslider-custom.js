   var slider = tns({
    container: ".my-slider",
    items: 4,
    gutter: 20,
    slideBy: 1,
    // controlsPosition: "bottom",
    // navPosition: "bottom",
    mouseDrag: false,
    autoplay: true,
    nav: false,
    autoplayButtonOutput: false,
    // autoplayTimeout:5000,
    controlsContainer: "#custom-control",
    responsive: {
      0: {
        items: 1,
        autoplayTimeout:50000,
        nav: false,
      },
      640: {
        items: 2,
        autoplayTimeout:5000,
        nav: false,
      },
      900: {
        items: 3,
        nav: false,
        autoplayTimeout:5000,        
      },
      1200: {
        items: 4,
        nav: false,
        autoplayTimeout:5000,
      }
    }
    // mode: 'gallery',
    // speed: 2000,
    // animateIn: "scale",
    // controls: false,
    // nav: false,
    // edgePadding: 20,
    // loop: false,
  });
  
 