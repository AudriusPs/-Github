<main>
   <!-- Hero -->
   <div class="container-hero text-center text-white">
        <img src="../app/images/mask-group-1.jpg" class="hero-foto" alt="hero h1">
        <div class="hero-h1">
          <h1 class="dontWrapIt">Laser Skin Resurfacing</h1>
        </div>
      </div>
      <!-- Hero END -->
      <!-- about -->
      <div class="container container-about pt-1 pt-md-5 mb-1 mb-md-5">
        <div class="spa-galery">
          <div class="row">
            <div class="col-12 col-md-12 col-lg-6 pb-3">
              <div class="image-container container-spa-galery d-none d-sm-block">
                <div class="container-about-small pb-2">
                  <img class="img-fluid about-img" src="../app/images/aboutr1.jpg" alt="senior-female-getting">
                </div>
              </div>
            </div>
            <div class="col-12 col-md-12 col-lg-6">
              <h4>We provide</h4>
              <h2>Welcome to Spa Center</h2>
              <p>Spread over two floors, our beautiful spa offer a soothing environment in which you can rest, relax and feel competely rejuvenated.</p>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. remaining essentially unchanged. It was popularised in the with theLorem Ipsum is simply dummy text of the printing and eentially unchanged.</p>
            </div>
          </div>
        </div>
      </div>
      <!--end about -->
      <!-- Our Services -->
      <div class="container-services-wide pt-1 pt-md-5">
        <div class="container container-services pe-md-5 ps-md-5">
          <div class="row services-h2">
            <div class="col-12 text-center pb-md-3 pb-1">
              <h2>Our Services</h2>
            </div>
          </div>
          <div class="row services-p">
            <div class="col-12 text-center pb-md-3 pb-1">
              <p>Spread over two floors, our beautiful spa offer a soothing environment in which you can rest, relax and feel competely rejuvenated.</p>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. remaining essentially unchanged. It was popularised in the with theLorem Ipsum is simply dummy text of the printing and eentially unchanged.</p>
            </div>
            <div>
              <div class="row justify-content-between">
                <div class="col-sm-2 circle-container">
                  <div id="circle-1" class="circle circle-group"></div>
                  <h4>Spa</h4>
                </div>
                <div class="col-sm-2 circle-container circle-group">
                  <div id="circle-2" class="circle"></div>
                  <h4>Hair Makeup</h4>
                </div>
                <div class="col-sm-2 circle-container circle-group">
                  <div id="circle-3" class="circle"></div>
                  <h4>Waxing</h4>
                </div>
                <div class="col-sm-2 circle-container circle-group">
                  <div id="circle-4" class="circle"></div>
                  <h4>Facial</h4>
                </div>
                <div class="col-sm-2 circle-container circle-group">
                  <div id="circle-5" class="circle"></div>
                  <h4>Massage</h4>
                </div>
              </div>
            </div>
            <div class="services-table bg-white">
              <div class="row services-box">
                <div class="col-12 col-md-5 col-lg-3 text-left pt-4 ps-0">
                  <ul class="list-group services-menu-ul list-unstyled">
                    <li class="list-group-item list-item">
                      <a class="services-menu text-black text-decoration-none" href="#">
                        <img src="../app/images/massage6.png" alt="Massage Therapy Icon" class="icon i-massage6">Massage Therapy </a>
                    </li>
                    <li class="list-group-item list-item">
                      <a class="services-menu text-black text-decoration-none" href="#">
                        <img src="../app/images/massage6.png" alt="Massage Therapy Icon" class="icon  i-massage6">Facials </a>
                    </li>
                    <li class="list-group-item list-item">
                      <a class="services-menu text-black text-decoration-none" href="#">
                        <img src="../app/images/massage6.png" alt="Massage Therapy Icon" class="icon  i-massage6">Pedicures </a>
                    </li>
                    <li class="list-group-item list-item">
                      <a class="services-menu text-black text-decoration-none" href="#">
                        <img src="../app/images/massage6.png" alt="Massage Therapy Icon" class="icon  i-massage6">Manicures </a>
                    </li>
                    <li class="list-group-item list-item">
                      <a class="services-menu text-black text-decoration-none" href="#">
                        <img src="../app/images/massage6.png" alt="Massage Therapy Icon" class="icon  i-massage6">Body Wraps </a>
                    </li>
                    <li class="list-group-item list-item">
                      <a class="services-menu text-black text-decoration-none" href="#">
                        <img src="../app/images/massage6.png" alt="Massage Therapy Icon" class="icon  i-massage6">Waxing & Cosmetics </a>
                    </li>
                  </ul>
                </div>
                <div class="col-12 col-md-7 col-lg-4 pt-md-4 ps-5">
                  <div class="image-container container-serv-galery d-none d-sm-none d-md-block">
                    <img class="img-fluid" src="../app/images/Ellipse_foto.png" alt="face massage">
                  </div>
                </div>
                <div class="col-12 col-md-12 col-lg-5 text-left pt-5 services-text">
                  <h2>Massage Therapy</h2>
                  <h4>$40 - $80</h4>
                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. remaining essentially unchanged. It was popularised in the with theLorem Ipsum is simply dummy text of the printing and eentially unchanged.</p>
                  <h6>
                    <a href="" class="text-decoration-none">Read More</a>
                  </h6>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Our Services END-->
      <!-- BEAUTY AND SPA CENTER -->
      <div class="container container-spa pt-1 pt-lg-5 pb-1 pb-lg-5">
        <div class="row">
          <div class="col-auto heading-spa">
            <h2>BEAUTY AND SPA CENTER</h2>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. remaining essentially unchanged. It was popularised in the with theLorem Ipsum is simply dummy text of the printing and eentially unchanged.</p>
          </div>
        </div>
        <div class="spa-galery">
          <div class="row">
            <div class="col-12 col-md-6 col-lg-4">
              <div class="image-container container-spa-galery pb-2">
                <a href>
                  <img src="../app/images/woman-treatment-procedures.jpg" class="img-fluid spa-img" alt="woman-treatment-procedures">
                </a>
                <div class="bg-white opacity-75 text-center name-box pt-2">
                  <p>Sauna Massage</p>
                  <h6>NATURAL HEALTH</h6>
                </div>
              </div>
            </div>
            <div class="col-12 col-md-6 col-lg-4">
              <div class="image-container container-spa-galery pb-2">
                <a href>
                  <img src="../app/images/1.jpg" class="img-fluid spa-img" alt="face procedures">
                </a>
                <div class="bg-white opacity-75 text-center name-box pt-2">
                  <p>Spa Treatment</p>
                  <h6>Mind Relaxation</h6>
                </div>
              </div>
            </div>
            <div class="col-12 col-md-6 col-lg-4">
              <div class="image-container container-spa-galery pb-2">
                <a href>
                  <img src="../app/images/woman-cosmetology.jpg" class="img-fluid spa-img" alt="hand procedures">
                </a>
                <div class="bg-white opacity-75 text-center name-box pt-2">
                  <p>Cosmetology</p>
                  <h6>Essential Balance</h6>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- BEAUTY AND SPA CENTER end-->
      <!-- team -->
      <div class=" container-team-wide pt-1 pt-lg-5 pb-1 pb-lg-5">
        <div class="container container-team pt-1 pt-md-4">
          <div class="row team-h2">
            <div class="col-12 text-center">
              <h2>Our Experience Specialists</h2>
            </div>
          </div>
          <div class="row team-p">
            <div class="col-12 text-center">
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
            </div>
          </div>
          <div class="Specialists-galery">
            <div class="row">
              <div class="col-12 col-md-6 col-lg-4 pb-3">
                <div class="image-container container-team-1 mb-2">
                  <a href>
                    <img src="../app/images/expert1.jpg" class="img-fluid image-team-1" alt="expert1">
                  </a>
                  <div class="middle-team-1">
                    <div class="text-team-1">
                      <h4>Mattie Joshef</h4>
                      <p>Dermatologist</p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-12 col-md-6 col-lg-4 pb-3">
                <div class="image-container container-team-2 mb-2">
                  <a href>
                    <img src="../app/images/expert2.jpg" class="img-fluid image-team-2" alt="expert2">
                  </a>
                  <div class="middle-team-2">
                    <div class="text-team-2">
                      <h4>Mattie Joshef</h4>
                      <p>Dermatologist</p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-12 col-md-6 col-lg-4">
                <div class="image-container container-team-3 mb-2">
                  <a href>
                    <img src="../app/images/expert3.jpg" class="img-fluid image-team-3" alt="expert3">
                  </a>
                  <div class="middle-team-3">
                    <div class="text-team-3">
                      <h4>Mattie Joshef</h4>
                      <p>Dermatologist</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- team end-->
      <!-- products -->
      <div class="container container-products bg-white pt-1 mt-lg-5 pb-1 pb-lg-5">
        <div class="row">
          <div class="col-md-12 col-xl-7">
            <div class="row">
              <div class="col-12 products-text">
                <h2>Our Exclusive Products</h2>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
              </div>
            </div>
          </div>
          <div class="col-md-12 col-xl-5 ps-3">
            <div class="row">
              <div class="col-md-9 col-xl-3"></div>
              <div class="col-md-9 col-xl-3 pb-4">
                <button class="btn btn-primary" id="submit2" name="submit2" type="submit">All Products</button>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12 ">
            <div class="slider-container">
              <ul class="control" id="custom-control">
                <li class="prev">
                  <i class="bi bi-arrow-left d-md-block d-lg-none"></i>
                </li>
                <li class="next">
                  <i class="bi bi-arrow-right d-md-block d-lg-none"></i>
                </li>
              </ul>
              <div class="my-slider">
                <img class="img-thumbnail border-0 slider-img" src="../app/images/product1.png" alt="product1">
                <img class="img-thumbnail border-0 slider-img" src="../app/images/product2.png" alt="product2">
                <img class="img-thumbnail border-0 slider-img" src="../app/images/product3.png" alt="product3">
                <img class="img-thumbnail border-0 slider-img" src="../app/images/product4.png" alt="product4">
                <img class="img-thumbnail border-0 slider-img" src="../app/images/product1.png" alt="product1">
                <img class="img-thumbnail border-0 slider-img" src="../app/images/product2.png" alt="product2">
                <img class="img-thumbnail border-0 slider-img" src="../app/images/product3.png" alt="product3">
                <img class="img-thumbnail border-0 slider-img" src="../app/images/product4.png" alt="product4">
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- products end-->
      <!-- offers -->
      <div class="container-offers-wide pt-1 pb-1">
        <div class="container container-offers pt-lg-5 pb-lg-5">
          <div class="row offers">
            <div class="col-md-12 col-xl-7 text-left">
              <div class="row">
                <div class="col-md-12 col-xl-12 text-left">
                  <h2>Our Special Offers</h2>
                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
                  <div>
                    <img class="img-fluid" src="../app/images/image1.jpg" alt="counter">
                  </div>
                </div>
              </div>
            </div>
            <div class="col-12 col-md-12 col-lg-5">
              <div class="image-container container-spa-galery d-none d-sm-block">
                <div class="container-about-small pb-2">
                  <img class="img-fluid about-img" src="../app/images/ausys_foto.png" alt="senior-female-getting">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!--end offers -->
      <!--contacts -->
      <div class="container-contact-wide p-2 pt-md-5 pb-1 pb-lg-5">
        <div class="row pb-lg-5 ms-0 me-0">
          <div class="col-12 col-md-12 col-lg-3"></div>
          <div class="col-12 col-md-12 col-lg-6 text-center">
            <div class="container container-contact-big">
              <div class="row contact-h2">
                <div class="col-12 col-md-12 col-lg-2 text-center"></div>
                <div class="col-12 col-md-12 col-lg-8 text-center text-white pb-md-2 pt-md-5">
                  <h2>Make An Appointment</h2>
                </div>
                <div class="col-12 col-md-12 col-lg-2 text-center"></div>
              </div>
              <div class="row contact-p">
                <div class="col-12 col-md-12 col-lg-1 text-center"></div>
                <div class="col-12 col-md-12 col-lg-10 text-center text-white pb-md-2">
                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting <br>Lorem Ipsum has been industry </p>
                </div>
                <div class="col-12 col-md-12 col-lg-1 text-center"></div>
                <div class="container container-contact bg-white p-4">
                  <div class="row">
                    <form id="contact" action="index.php" method="post">
                      <div class="row contact-y-1 pb-1 pb-xs-5 pb-xl-5">
                        <div class="col-md-12 col-xl-6">
                          <div class="">
                            <input class="form-control" id="name" name="vardas" type="text" placeholder="Name" required>
                          </div>
                        </div>
                        <div class="col-md-12 col-xl-6">
                          <div class="">
                            <input class="form-control" id="emailAddress" name="email" type="email" placeholder="Email" required>
                          </div>
                        </div>
                      </div>
                      <div class="row contact-y-2 pb-3 pb-xs-5">
                        <div class="col-md-12 col-xl-6">
                          <div class="">
                            <input class="form-control" id="phone" type="text" placeholder="Phone">
                          </div>
                        </div>
                        <div class="col-md-12 col-xl-6">
                          <div class="">
                            <textarea class="form-control" id="message" name="message" placeholder="Message" rows="1"></textarea>
                          </div>
                        </div>
                      </div>
                      <div class="row contact-y-3 pt-1 pt-md-4">
                        <div class="col-5 col-md-7"></div>
                        <div class="col-7 col-md-5">
                          <button class="btn btn-primary" id="submit" name="submit" type="submit">Send</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-12 col-md-12 col-lg-3 p-0"></div>
        </div>
      </div>
      <!--end contact -->
      <!-- blog -->
      <div class="container container-blog mb-3 mb-lg-5 pt-2 pt-md-5 pb-lg-5">
        <div class="row">
          <div class="col-12 text-center pb-1 pb-md-3">
            <h2>Our Blog</h2>
          </div>
        </div>
        <div class="row blog-p">
          <div class="col-2 text-center"></div>
          <div class="col-12 col-lg-8 text-center">
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
          </div>
          <div class="col-2 text-center"></div>
        </div>
        <div class="row blog-galery">
          <div class="col-12 col-md-12 col-lg-6 col-blog pt-1 pt-md-5 pe-1">
            <div class="card-blog-1">
              <img src="../app/images/2.jpg" class="card-img-top" alt="laser procedure">
              <div class="card-body-blog">
                <div class="row blog-row ps-4 ps-md-5 pe-1 pe-md-4">
                  <div class="row blog-row-comm bg-white align-items-center">
                    <div class="col-1 col-md-1 col-xl-1">
                      <img src="../app/images/3.jpg" class="rounded-circle blog-elipse d-none d-md-block" alt="blog comenter">
                    </div>
                    <div class="col-5 col-md-8 col-xl-7">
                      <p>Rubina Alfa</p>
                    </div>
                    <div class="col-6 col-md-3 col-xl-4">
                      <p>
                        <img src="../app/images/calendar.png" alt="calendar Icon" class="icon">12 Oct 2021
                      </p>
                    </div>
                  </div>
                </div>
                <div class="row text-left pt-3 ps-5">
                  <h4>Specialty Spa Treatments For Your Face, Body, Hands, & Feet</h4>
                </div>
                <div class="row ps-5 pt-1 pt-md-4">
                  <a href="#" class="btn btn-primary read-more">Read More</a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-12 col-md-12 col-lg-6 col-blog pt-1 pt-md-5 pe-1">
            <div class="card-body-blog card-body-blog-1">
              <div class="row blog-row ps-4 ps-md-5 pe-1 pe-md-4">
                <div class="row blog-row-comm bg-white align-items-center">
                  <div class="col-1 col-md-1 col-xl-1">
                    <img src="../app/images/3.jpg" class="rounded-circle blog-elipse d-none d-md-block" alt="blog comenter">
                  </div>
                  <div class="col-5 col-md-8 col-xl-7">
                    <p>Rubina Alfa</p>
                  </div>
                  <div class="col-6 col-md-3 col-xl-4">
                    <p>
                      <img src="../app/images/calendar.png" alt="calendar Icon" class="icon">12 Oct 2021
                    </p>
                  </div>
                </div>
              </div>
              <div class="row text-left pt-3 ps-5 pe-5">
                <h4>Specialty Spa Treatments For Your Face, Body, Hands, & Feet</h4>
              </div>
              <div class="row ps-5 pt-1 pt-md-5 mb-2 mb-md-5">
                <a href="#" class="btn btn-primary read-more">Read More</a>
              </div>
            </div>
            <div class="card-body-blog card-body-blog-2 mt-1 mt-md-4">
              <div class="row blog-row ps-4 ps-md-5 pe-1 pe-md-4">
                <div class="row blog-row-comm bg-white align-items-center">
                  <div class="col-1 col-md-1 col-xl-1">
                    <img src="../app/images/3.jpg" class="rounded-circle blog-elipse d-none d-md-block" alt="blog comenter">
                  </div>
                  <div class="col-5 col-md-8 col-xl-7">
                    <p>Rubina Alfa</p>
                  </div>
                  <div class="col-6 col-md-3 col-xl-4">
                    <p>
                      <img src="../app/images/calendar.png" alt="calendar Icon" class="icon">12 Oct 2021
                    </p>
                  </div>
                </div>
              </div>
              <div class="row text-left pt-3 ps-5 pe-5">
                <h4>Specialty Spa Treatments For Your Face, Body, Hands, & Feet</h4>
              </div>
              <div class="row ps-5 pt-1 pt-md-5">
                <a href="#" class="btn btn-primary read-more">Read More</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- blog end-->
</main>